%% 数据处理
clc
clear
Data_pro = readtable("2022_APMCM_E_Data.xlsx",'Sheet', 'proliferation');
Data_cell = table2cell(Data_pro);
[N,M] = size(Data_cell);
Data_val = zeros(N,4);

for i=1:N
    Data_val(i,1) = Data_cell{i,3};
    Data_val(i,2) = Data_cell{i,4};
    Data_val(i,3) = Data_cell{i,5};
    Data_val(i,4) = Data_cell{i,6};
end

data = Data_val(:,4);
perVal = 20;
perLayer = 10;

%% 模型训练
if ~exist('training_net2a.mat','file')
    force=data;
    T=tonndata(force,false,false);  %输入和输出矩阵须为cell类型的矩阵，且不能用num2cell来转换，如果使用二维cell矩阵，将会被认为是两个输入从而不能训练。
    trainFcn = 'trainbr';   %默认的lmh函数训练时间序列效果很差，采用贝叶斯正则化算法
    
    feedbackDelays = 1:perVal;    %延迟向量
    hiddenLayerSize = perLayer;
    net = narnet(feedbackDelays,hiddenLayerSize,'open',trainFcn);
    [Xs,Xi,Ai,Ts] = preparets(net,{},{},T);
    net.divideParam.trainRatio = 70/100;
    net.divideParam.valRatio = 15/100;
    net.divideParam.testRatio = 15/100;
    net = train(net,Xs,Ts,Xi,Ai);
    view(net);
    save('training_net2a.mat','net');
end
%% 预测
net = importdata('training_net2a.mat');
PreYear = 130-perVal;
len = length(data);
%预测的数据
p = zeros(1,len+perVal);
%前perVal个不预测直接用现成的
p(1:perVal)= data(1:perVal);
for i=1:len-perVal
    %依次用perVal个准确的预测下一个
    ytest = num2cell(data(i:i + perVal)');
    [AA,AB,AC] = preparets(net,{},{},[ytest(perVal) ytest]);
    temp1 = net(AA,AB,AC);
    p(i+perVal) = temp1{1};
end
p2 = p;
for i=1:PreYear
    %迭代预测后续
    ytest = num2cell(p(len+i-perVal-1:len+i-1));
    [AA,AB,AC] = preparets(net,{},{},[ytest(perVal) ytest]);
    temp1 = net(AA,AB,AC);
    p(i+len) = temp1{1};
    p2(i+len) = ceil(p(i+len));
end
%% 显示预测结果
startYear = Data_val(1,1);
X_p_1 = [startYear:1:startYear+len-1];
X_p_2 = [startYear:1:startYear+length(p)-1];
figure(2)
hold on
plot(X_p_1,data,'r');
plot(X_p_2,p,'b--');
legend({'真实值','预测值'});
title('全球拥核国家数量')